package com.mohammed.rayzrcare

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

data class ServiceRecord(
    val id: Long,
    val type: String,
    val date: String,
    val dueDate: String?,
    val notes: String = ""
)

data class FuelRecord(val id: Long, val date: String, val amount: String, val notes: String = "")

class Store(private val context: Context) {
    private val prefs = context.getSharedPreferences("rayzr", Context.MODE_PRIVATE)

    fun services(): MutableList<ServiceRecord> {
        val raw = prefs.getString("services", null)
        if (raw == null) {
            val seed = mutableListOf(
                ServiceRecord(1, "زيت المحرك", "2026-09-10", "2026-10-10", "تبديل زيت المحرك"),
                ServiceRecord(2, "الأدامة وصنفرة الكلتشات", "2026-09-22", "2027-03-22", "أدامة وتنظيف وصنفرة"),
                ServiceRecord(3, "فلتر الهواء", "2026-09-22", null, "تبديل فلتر الهواء")
            )
            saveServices(seed)
            return seed
        }
        val a = JSONArray(raw)
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i)
            ServiceRecord(o.getLong("id"), o.getString("type"), o.getString("date"),
                if (o.isNull("due")) null else o.getString("due"), o.optString("notes"))
        }
    }

    fun saveServices(list: List<ServiceRecord>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().apply {
                put("id", it.id); put("type", it.type); put("date", it.date)
                put("due", it.dueDate ?: JSONObject.NULL); put("notes", it.notes)
            })
        }
        prefs.edit().putString("services", a.toString()).apply()
    }

    fun fuels(): MutableList<FuelRecord> {
        val a = JSONArray(prefs.getString("fuels", "[]"))
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i)
            FuelRecord(o.getLong("id"), o.getString("date"), o.getString("amount"), o.optString("notes"))
        }
    }

    fun saveFuels(list: List<FuelRecord>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().apply {
            put("id", it.id); put("date", it.date); put("amount", it.amount); put("notes", it.notes)
        })}
        prefs.edit().putString("fuels", a.toString()).apply()
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val due = Store(applicationContext).services()
            .filter { it.dueDate != null }
            .map { it to ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it.dueDate)) }
            .filter { it.second in 0..3 }
        if (due.isNotEmpty()) {
            val nm = applicationContext.getSystemService(NotificationManager::class.java)
            val channel = "maintenance"
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                NotificationChannel(channel, "مواعيد الصيانة", NotificationManager.IMPORTANCE_DEFAULT)
            )
            due.forEachIndexed { index, (s, days) ->
                val msg = if (days == 0L) "اليوم موعد ${s.type}" else "باقي $days يوم على ${s.type}"
                nm.notify(100 + index, NotificationCompat.Builder(applicationContext, channel)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("RayZR Care").setContentText(msg).setAutoCancel(true).build())
            }
        }
        return Result.success()
    }
}

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "rayzr-reminders", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build()
        )
        setContent { RayZRApp(Store(this)) }
    }
}

enum class Tab { HOME, SERVICE, HISTORY, FUEL, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RayZRApp(store: Store) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var services by remember { mutableStateOf(store.services()) }
    var fuels by remember { mutableStateOf(store.fuels()) }
    var editing by remember { mutableStateOf<ServiceRecord?>(null) }
    var showServiceEditor by remember { mutableStateOf(false) }
    var showFuelEditor by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF35A7FF), secondary = Color(0xFF72E39A),
            background = Color(0xFF07111A), surface = Color(0xFF0D1B27)
        )
    ) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                topBar = { TopAppBar(title = { Text("RayZR Care") }, actions = {
                    Icon(Icons.Default.TwoWheeler, null, modifier = Modifier.padding(16.dp))
                })},
                bottomBar = {
                    NavigationBar {
                        listOf(
                            Tab.HOME to (Icons.Default.Home to "الرئيسية"),
                            Tab.SERVICE to (Icons.Default.Build to "الصيانة"),
                            Tab.HISTORY to (Icons.Default.History to "السجل"),
                            Tab.FUEL to (Icons.Default.LocalGasStation to "البنزين"),
                            Tab.SETTINGS to (Icons.Default.Settings to "الإعدادات")
                        ).forEach { (t, p) ->
                            NavigationBarItem(selected = tab == t, onClick = { tab = t },
                                icon = { Icon(p.first, p.second) }, label = { Text(p.second) })
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == Tab.SERVICE || tab == Tab.HISTORY) FloatingActionButton(onClick = {
                        editing = null; showServiceEditor = true
                    }) { Icon(Icons.Default.Add, "إضافة") }
                    else if (tab == Tab.FUEL) FloatingActionButton(onClick = { showFuelEditor = true }) {
                        Icon(Icons.Default.Add, "إضافة تعبئة")
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        Tab.HOME -> Home(services)
                        Tab.SERVICE -> Services(services, onEdit = { editing = it; showServiceEditor = true },
                            onDelete = { r -> services = services.filterNot { it.id == r.id }.toMutableList(); store.saveServices(services) })
                        Tab.HISTORY -> History(services)
                        Tab.FUEL -> Fuel(fuels, onDelete = { r -> fuels = fuels.filterNot { it.id == r.id }.toMutableList(); store.saveFuels(fuels) })
                        Tab.SETTINGS -> Settings()
                    }
                }
            }

            if (showServiceEditor) ServiceEditor(editing, onDismiss = { showServiceEditor = false }, onSave = { r ->
                val next = services.toMutableList()
                val i = next.indexOfFirst { it.id == r.id }
                if (i >= 0) next[i] = r else next.add(0, r)
                services = next; store.saveServices(next); showServiceEditor = false
            })
            if (showFuelEditor) FuelEditor(onDismiss = { showFuelEditor = false }, onSave = { r ->
                fuels = (listOf(r) + fuels).toMutableList(); store.saveFuels(fuels); showFuelEditor = false
            })
        }
    }
}

fun daysUntil(date: String?): Long? = try {
    date?.let { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it)) }
} catch (_: Exception) { null }

@Composable
fun Home(services: List<ServiceRecord>) {
    val upcoming = services.filter { it.dueDate != null }.sortedBy { it.dueDate }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("مرحباً محمد 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Yamaha RayZR 125 • متابعة أوفلاين", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(10.dp))
                        Text("حالة الدراجة جيدة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Text("يتم حساب المواعيد من تاريخ الهاتف تلقائياً.")
                }
            }
        }
        items(upcoming) { s -> DueCard(s) }
    }
}

@Composable
fun DueCard(s: ServiceRecord) {
    val d = daysUntil(s.dueDate)
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (s.type.contains("زيت")) Icons.Default.Opacity else Icons.Default.Build, null)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.type, fontWeight = FontWeight.Bold)
                Text("آخر صيانة: ${s.date}")
                Text("الاستحقاق: ${s.dueDate}")
            }
            Text(when {
                d == null -> ""
                d < 0 -> "متأخر ${-d} يوم"
                d == 0L -> "اليوم"
                else -> "باقي $d يوم"
            }, fontWeight = FontWeight.Bold, color = if (d != null && d <= 3) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
fun Services(list: List<ServiceRecord>, onEdit: (ServiceRecord)->Unit, onDelete: (ServiceRecord)->Unit) {
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الصيانة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        items(list, key = { it.id }) { s ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(s.type, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("التاريخ: ${s.date}")
                    if (s.dueDate != null) Text("الاستحقاق: ${s.dueDate}")
                    if (s.notes.isNotBlank()) Text(s.notes, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row {
                        TextButton(onClick = { onEdit(s) }) { Text("تعديل") }
                        TextButton(onClick = { onDelete(s) }) { Text("حذف") }
                    }
                }
            }
        }
    }
}

@Composable
fun History(list: List<ServiceRecord>) {
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("سجل الصيانة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        items(list.sortedByDescending { it.date }) { s ->
            ListItem(headlineContent = { Text(s.type) }, supportingContent = { Text("${s.date} • ${s.notes}") },
                leadingContent = { Icon(Icons.Default.History, null) })
            HorizontalDivider()
        }
    }
}

@Composable
fun Fuel(list: List<FuelRecord>, onDelete: (FuelRecord)->Unit) {
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("سجل البنزين", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        if (list.isEmpty()) item { Text("ماكو تعبئات مسجلة بعد. اضغط + لإضافة أول تعبئة.") }
        items(list, key = { it.id }) { f ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalGasStation, null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(f.date, fontWeight = FontWeight.Bold); Text("${f.amount} • ${f.notes}") }
                    IconButton(onClick = { onDelete(f) }) { Icon(Icons.Default.Delete, "حذف") }
                }
            }
        }
    }
}

@Composable
fun Settings() {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        ListItem(headlineContent = { Text("الدراجة") }, supportingContent = { Text("Yamaha RayZR 125") }, leadingContent = { Icon(Icons.Default.TwoWheeler, null) })
        ListItem(headlineContent = { Text("العمل بدون إنترنت") }, supportingContent = { Text("كل السجلات محفوظة محلياً على الجهاز") }, leadingContent = { Icon(Icons.Default.CloudOff, null) })
        ListItem(headlineContent = { Text("التنبيهات") }, supportingContent = { Text("فحص يومي للمواعيد القريبة") }, leadingContent = { Icon(Icons.Default.Notifications, null) })
        Text("RayZR Care v0.1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceEditor(existing: ServiceRecord?, onDismiss: ()->Unit, onSave: (ServiceRecord)->Unit) {
    var type by remember { mutableStateOf(existing?.type ?: "") }
    var date by remember { mutableStateOf(existing?.date ?: LocalDate.now().toString()) }
    var due by remember { mutableStateOf(existing?.dueDate ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var error by remember { mutableStateOf("") }

    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "إضافة صيانة" else "تعديل الصيانة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(type, { type = it }, label = { Text("نوع الصيانة") })
                OutlinedTextField(date, { date = it }, label = { Text("التاريخ YYYY-MM-DD") })
                OutlinedTextField(due, { due = it }, label = { Text("الاستحقاق القادم (اختياري)") })
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") })
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { Button(onClick = {
            try {
                LocalDate.parse(date); if (due.isNotBlank()) LocalDate.parse(due)
                if (type.isBlank()) { error = "اكتب نوع الصيانة"; return@Button }
                onSave(ServiceRecord(existing?.id ?: System.currentTimeMillis(), type.trim(), date, due.ifBlank { null }, notes.trim()))
            } catch (_: Exception) { error = "صيغة التاريخ لازم تكون YYYY-MM-DD" }
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun FuelEditor(onDismiss: ()->Unit, onSave: (FuelRecord)->Unit) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var amount by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة تعبئة بنزين") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(date, { date = it }, label = { Text("التاريخ YYYY-MM-DD") })
            OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ أو الكمية") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text))
            OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") })
        }},
        confirmButton = { Button(onClick = {
            try { LocalDate.parse(date); if (amount.isNotBlank()) onSave(FuelRecord(System.currentTimeMillis(), date, amount, notes)) }
            catch (_: Exception) {}
        }) { Text("حفظ") }},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}
