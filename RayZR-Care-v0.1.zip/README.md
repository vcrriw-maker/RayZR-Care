# RayZR Care

Offline Android maintenance tracker for a Yamaha RayZR 125.

## Initial data
- Engine oil changed: 2026-09-10
- Maintenance / clutch sanding: 2026-09-22
- Air filter changed: 2026-09-22
- Next oil service: 2026-10-10
- Next maintenance: 2027-03-22

## v0.1
- Arabic RTL UI
- Home, maintenance, history, fuel and settings screens
- Add / edit / delete maintenance records
- Local persistence using SharedPreferences JSON
- Automatic day countdown from device date
- Offline local notifications with WorkManager
- Bootstrapped sample records
