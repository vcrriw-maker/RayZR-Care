package com.mohammed.rayzrcare

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

data class ServiceRecord(val id: Long, val type: String, val date: String, val dueDate: String?, val notes: String = "", val imageUri: String? = null)
data class FuelRecord(val id: Long, val date: String, val amount: String, val notes: String = "", val imageUri: String? = null)
data class Profile(val name: String = "", val motorcycle: String = "", val imageUri: String? = null)
enum class Tab { HOME, SERVICE, HISTORY, FUEL, SETTINGS }

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("rayzr", Context.MODE_PRIVATE)
    init { prefs.edit().remove("background").apply() }
    private fun array(key: String) = JSONArray(prefs.getString(key, "[]") ?: "[]")

    fun services(): MutableList<ServiceRecord> {
        val values = array("services")
        return MutableList(values.length()) { i -> values.getJSONObject(i).let { value ->
            ServiceRecord(value.getLong("id"), value.getString("type"), value.getString("date"), if (value.isNull("due")) null else value.getString("due"), value.optString("notes"), value.optString("image").ifBlank { null })
        } }
    }

    fun saveServices(list: List<ServiceRecord>) { prefs.edit().putString("services", JSONArray().apply { list.forEach { record -> put(JSONObject().apply { put("id", record.id); put("type", record.type); put("date", record.date); put("due", record.dueDate ?: JSONObject.NULL); put("notes", record.notes); put("image", record.imageUri ?: JSONObject.NULL) }) } }.toString()).apply() }

    fun fuels(): MutableList<FuelRecord> {
        val values = array("fuels")
        return MutableList(values.length()) { i -> values.getJSONObject(i).let { value -> FuelRecord(value.getLong("id"), value.getString("date"), value.getString("amount"), value.optString("notes"), value.optString("image").ifBlank { null }) } }
    }

    fun saveFuels(list: List<FuelRecord>) { prefs.edit().putString("fuels", JSONArray().apply { list.forEach { record -> put(JSONObject().apply { put("id", record.id); put("date", record.date); put("amount", record.amount); put("notes", record.notes); put("image", record.imageUri ?: JSONObject.NULL) }) } }.toString()).apply() }
    fun profile() = Profile(prefs.getString("name", "") ?: "", prefs.getString("motorcycle", "") ?: "", prefs.getString("profile_image", null))
    fun saveProfile(value: Profile) { prefs.edit().putString("name", value.name).putString("motorcycle", value.motorcycle).putString("profile_image", value.imageUri).apply() }

    fun backgrounds(): MutableMap<Tab, String> {
        val values = JSONObject(prefs.getString("backgrounds", "{}") ?: "{}")
        return Tab.values().mapNotNull { tab -> if (values.has(tab.name)) tab to values.getString(tab.name) else null }.toMap().toMutableMap()
    }

    fun saveBackground(tab: Tab, uri: String?, current: Map<Tab, String>) {
        val next = current.toMutableMap().apply { if (uri == null) remove(tab) else set(tab, uri) }
        prefs.edit().putString("backgrounds", JSONObject().apply { next.forEach { (section, value) -> put(section.name, value) } }.toString()).apply()
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val due = Store(applicationContext).services().filter { it.dueDate != null }.map { it to ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it.dueDate)) }.filter { it.second in 0..3 }
        if (due.isNotEmpty()) {
            val manager = applicationContext.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("maintenance", "مواعيد الصيانة", NotificationManager.IMPORTANCE_DEFAULT))
            due.forEachIndexed { index, (service, days) -> manager.notify(100 + index, NotificationCompat.Builder(applicationContext, "maintenance").setSmallIcon(R.drawable.ic_stat_rayzr).setContentTitle("RayZR Care").setContentText(if (days == 0L) "اليوم موعد ${service.type}" else "باقي $days يوم على ${service.type}").setAutoCancel(true).build()) }
        }
        return Result.success()
    }
}

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("rayzr-reminders", ExistingPeriodicWorkPolicy.UPDATE, PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build())
        setContent { RayZRApp(Store(this)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RayZRApp(store: Store) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var services by remember { mutableStateOf(store.services()) }
    var fuels by remember { mutableStateOf(store.fuels()) }
    var profile by remember { mutableStateOf(store.profile()) }
    var backgrounds by remember { mutableStateOf(store.backgrounds()) }
    var backgroundTarget by remember { mutableStateOf<Tab?>(null) }
    var editing by remember { mutableStateOf<ServiceRecord?>(null) }
    var editingFuel by remember { mutableStateOf<FuelRecord?>(null) }
    var serviceEditor by remember { mutableStateOf(false) }
    var fuelEditor by remember { mutableStateOf(false) }

    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val target = backgroundTarget ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
            store.saveBackground(target, uri.toString(), backgrounds)
            backgrounds = store.backgrounds()
        }
        backgroundTarget = null
    }
    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
            profile = profile.copy(imageUri = uri.toString()); store.saveProfile(profile)
        }
    }
    val chooseBackground: (Tab) -> Unit = { target -> backgroundTarget = target; backgroundPicker.launch(arrayOf("image/*")) }
    val resetBackground: (Tab) -> Unit = { target -> store.saveBackground(target, null, backgrounds); backgrounds = store.backgrounds() }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF006B9A), onPrimary = Color.White, secondary = Color(0xFF2E7650), background = Color(0xFFF5F8FA), surface = Color.White, surfaceVariant = Color(0xFFE8F0F4))) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(containerColor = Color(0xFFF5F8FA), topBar = { TopAppBar(title = { Text("RayZR Care", fontWeight = FontWeight.Bold) }, actions = { Icon(Icons.Default.TwoWheeler, null, Modifier.padding(16.dp)) }) }, bottomBar = { NavigationBar { listOf(Tab.HOME to (Icons.Default.Home to "الرئيسية"), Tab.SERVICE to (Icons.Default.Build to "الصيانة"), Tab.HISTORY to (Icons.Default.History to "السجل"), Tab.FUEL to (Icons.Default.LocalGasStation to "البنزين"), Tab.SETTINGS to (Icons.Default.Settings to "الإعدادات")).forEach { (item, label) -> NavigationBarItem(tab == item, { tab = item }, icon = { Icon(label.first, label.second) }, label = { Text(label.second) }) } } }, floatingActionButton = { if (tab == Tab.SERVICE || tab == Tab.HISTORY) FloatingActionButton({ editing = null; serviceEditor = true }) { Icon(Icons.Default.Add, "إضافة") } else if (tab == Tab.FUEL) FloatingActionButton({ editingFuel = null; fuelEditor = true }) { Icon(Icons.Default.Add, "إضافة تعبئة") } }) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (tab) {
                        Tab.HOME -> Home(backgrounds[Tab.HOME], { chooseBackground(Tab.HOME) }, { resetBackground(Tab.HOME) }, services, profile)
                        Tab.SERVICE -> Services(backgrounds[Tab.SERVICE], { chooseBackground(Tab.SERVICE) }, { resetBackground(Tab.SERVICE) }, services, { editing = it; serviceEditor = true }, { record -> services = services.filterNot { it.id == record.id }.toMutableList(); store.saveServices(services) })
                        Tab.HISTORY -> History(backgrounds[Tab.HISTORY], { chooseBackground(Tab.HISTORY) }, { resetBackground(Tab.HISTORY) }, services)
                        Tab.FUEL -> Fuel(backgrounds[Tab.FUEL], { chooseBackground(Tab.FUEL) }, { resetBackground(Tab.FUEL) }, fuels, { editingFuel = it; fuelEditor = true }, { record -> fuels = fuels.filterNot { it.id == record.id }.toMutableList(); store.saveFuels(fuels) })
                        Tab.SETTINGS -> Settings(backgrounds[Tab.SETTINGS], { chooseBackground(Tab.SETTINGS) }, { resetBackground(Tab.SETTINGS) }, profile, { profile = it; store.saveProfile(it) }, { profilePicker.launch(arrayOf("image/*")) })
                    }
                }
            }
            if (serviceEditor) ServiceEditor(editing, { serviceEditor = false }, { record -> val next = services.toMutableList(); val index = next.indexOfFirst { it.id == record.id }; if (index >= 0) next[index] = record else next.add(0, record); services = next; store.saveServices(next); serviceEditor = false })
            if (fuelEditor) FuelEditor(editingFuel, { fuelEditor = false }, { record -> val next = fuels.toMutableList(); val index = next.indexOfFirst { it.id == record.id }; if (index >= 0) next[index] = record else next.add(0, record); fuels = next; store.saveFuels(next); fuelEditor = false })
        }
    }
}

@Composable
fun SectionFrame(backgroundUri: String?, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        if (backgroundUri != null) UriImage(Uri.parse(backgroundUri), Modifier.fillMaxSize(), .2f)
        Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = .78f)))
        content()
    }
}

@Composable
fun BackgroundControls(backgroundUri: String?, onChoose: () -> Unit, onReset: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(onChoose, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)) { Icon(Icons.Default.AddPhotoAlternate, "اختيار خلفية"); Spacer(Modifier.width(6.dp)); Text(if (backgroundUri == null) "اختيار خلفية" else "تغيير الخلفية") }
        if (backgroundUri != null) OutlinedButton(onReset, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)) { Icon(Icons.Default.RestartAlt, "إزالة الخلفية"); Spacer(Modifier.width(4.dp)); Text("إزالة") }
    }
}

@Composable
fun Home(backgroundUri: String?, onChoose: () -> Unit, onReset: () -> Unit, services: List<ServiceRecord>, profile: Profile) {
    val upcoming = services.filter { it.dueDate != null }.sortedBy { it.dueDate }
    SectionFrame(backgroundUri) {
        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { BackgroundControls(backgroundUri, onChoose, onReset) }
            item { Text(if (profile.name.isBlank()) "أهلاً بك في RayZR Care" else "مرحباً ${profile.name}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(if (profile.motorcycle.isBlank()) "أنشئ ملف دراجتك وابدأ تسجيل صيانتها" else profile.motorcycle, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.TwoWheeler, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Text(if (services.isEmpty()) "جاهز لتسجيل أول صيانة" else "متابعة صيانة دراجتك", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }; Spacer(Modifier.height(6.dp)); Text(if (services.isEmpty()) "ستظهر مواعيدك وتنبيهاتك هنا بعد إضافة سجلاتك." else "يتم حساب المواعيد من تاريخ الهاتف تلقائياً.") } } }
            if (upcoming.isEmpty()) item { Text("لا توجد مواعيد قادمة", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(upcoming, key = { it.id }) { DueCard(it) }
        }
    }
}

@Composable fun DueCard(record: ServiceRecord) { val days = try { record.dueDate?.let { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it)) } } catch (_: Exception) { null }; Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Icon(if (record.type.contains("زيت")) Icons.Default.Opacity else Icons.Default.Build, null); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(record.type, fontWeight = FontWeight.Bold); Text("آخر صيانة: ${record.date}"); Text("الاستحقاق: ${record.dueDate}") }; Text(when { days == null -> ""; days < 0 -> "متأخر ${-days} يوم"; days == 0L -> "اليوم"; else -> "باقي $days يوم" }, fontWeight = FontWeight.Bold) } } }

@Composable fun Services(backgroundUri: String?, onChoose: () -> Unit, onReset: () -> Unit, list: List<ServiceRecord>, onEdit: (ServiceRecord) -> Unit, onDelete: (ServiceRecord) -> Unit) { SectionFrame(backgroundUri) { LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { BackgroundControls(backgroundUri, onChoose, onReset) }; item { Text("الصيانة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }; if (list.isEmpty()) item { EmptyState("لا توجد سجلات صيانة", "أضف أول سجل من زر +") }; items(list, key = { it.id }) { record -> RecordCard(record.type, record.date, record.notes, record.imageUri, { onEdit(record) }, { onDelete(record) }) } } } }
@Composable fun History(backgroundUri: String?, onChoose: () -> Unit, onReset: () -> Unit, list: List<ServiceRecord>) { SectionFrame(backgroundUri) { LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { item { BackgroundControls(backgroundUri, onChoose, onReset) }; item { Text("سجل الصيانة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }; if (list.isEmpty()) item { EmptyState("السجل فارغ", "ستظهر سجلاتك هنا بعد إضافتها") }; items(list.sortedByDescending { it.date }, key = { it.id }) { record -> ListItem(headlineContent = { Text(record.type) }, supportingContent = { Text(listOf(record.date, record.notes).filter { it.isNotBlank() }.joinToString(" • ")) }, leadingContent = { Icon(Icons.Default.History, null) }); HorizontalDivider() } } } }
@Composable fun Fuel(backgroundUri: String?, onChoose: () -> Unit, onReset: () -> Unit, list: List<FuelRecord>, onEdit: (FuelRecord) -> Unit, onDelete: (FuelRecord) -> Unit) { SectionFrame(backgroundUri) { LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { item { BackgroundControls(backgroundUri, onChoose, onReset) }; item { Text("سجل البنزين", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }; if (list.isEmpty()) item { EmptyState("لا توجد تعبئات", "أضف أول تعبئة من زر +") }; items(list, key = { it.id }) { record -> RecordCard("${record.amount} - ${record.date}", record.date, record.notes, record.imageUri, { onEdit(record) }, { onDelete(record) }) } } } }

@Composable fun UriImage(uri: Uri, modifier: Modifier, alpha: Float = 1f) { androidx.compose.ui.viewinterop.AndroidView(factory = { ImageView(it).apply { scaleType = ImageView.ScaleType.CENTER_CROP } }, update = { it.setImageURI(uri); it.alpha = alpha }, modifier = modifier) }
@Composable fun RecordCard(title: String, date: String, notes: String, image: String?, onEdit: () -> Unit, onDelete: () -> Unit) { Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { if (image != null) UriImage(Uri.parse(image), Modifier.size(58.dp).clip(RoundedCornerShape(10.dp))) else Icon(Icons.Default.Build, null, Modifier.padding(8.dp)); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(date); if (notes.isNotBlank()) Text(notes, color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton(onEdit) { Icon(Icons.Default.Edit, "تعديل") }; IconButton(onDelete) { Icon(Icons.Default.Delete, "حذف") } } } }
@Composable fun EmptyState(title: String, message: String) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, Modifier.size(40.dp)); Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.Bold); Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable
fun Settings(backgroundUri: String?, onChooseBackground: () -> Unit, onResetBackground: () -> Unit, profile: Profile, onProfile: (Profile) -> Unit, onChooseProfileImage: () -> Unit) {
    var editing by remember { mutableStateOf(false) }
    SectionFrame(backgroundUri) { LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { BackgroundControls(backgroundUri, onChooseBackground, onResetBackground) }
        item { Text("الإعدادات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { if (profile.imageUri != null) UriImage(Uri.parse(profile.imageUri), Modifier.size(56.dp).clip(RoundedCornerShape(28.dp))) else Icon(Icons.Default.TwoWheeler, null, Modifier.size(42.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("ملف الدراجة", fontWeight = FontWeight.Bold); Text(if (profile.motorcycle.isBlank()) "لم تتم إضافة بيانات بعد" else profile.motorcycle, color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton({ editing = true }) { Icon(Icons.Default.Edit, "تعديل الملف") }; IconButton(onChooseProfileImage) { Icon(Icons.Default.AddPhotoAlternate, "اختيار صورة الملف") } } } }
        item { ListItem(headlineContent = { Text("الصور والسجلات") }, supportingContent = { Text("يمكنك إضافة صورة من داخل كل نموذج صيانة أو تعبئة") }, leadingContent = { Icon(Icons.Default.PhotoLibrary, null) }) }
        item { ListItem(headlineContent = { Text("البيانات محلية") }, supportingContent = { Text("تبقى سجلاتك وصورك وخلفياتك محفوظة على هذا الجهاز") }, leadingContent = { Icon(Icons.Default.CloudOff, null) }) }
        item { Text("RayZR Care 1.0", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp)) }
    } }
    if (editing) ProfileEditor(profile, { editing = false }, { onProfile(it); editing = false })
}

@Composable fun ProfileEditor(profile: Profile, onDismiss: () -> Unit, onSave: (Profile) -> Unit) { var name by remember { mutableStateOf(profile.name) }; var motorcycle by remember { mutableStateOf(profile.motorcycle) }; AlertDialog(onDismissRequest = onDismiss, title = { Text("ملف الدراجة") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("اسم المالك (اختياري)") }); OutlinedTextField(motorcycle, { motorcycle = it }, label = { Text("اسم الدراجة (اختياري)") }) } }, confirmButton = { Button({ onSave(Profile(name.trim(), motorcycle.trim(), profile.imageUri)) }) { Text("حفظ") } }, dismissButton = { TextButton(onDismiss) { Text("إلغاء") } }) }

@Composable fun ServiceEditor(existing: ServiceRecord?, onDismiss: () -> Unit, onSave: (ServiceRecord) -> Unit) {
    val context = LocalContext.current
    var type by remember { mutableStateOf(existing?.type ?: "") }; var date by remember { mutableStateOf(existing?.date ?: LocalDate.now().toString()) }; var due by remember { mutableStateOf(existing?.dueDate ?: "") }; var notes by remember { mutableStateOf(existing?.notes ?: "") }; var image by remember { mutableStateOf(existing?.imageUri) }; var error by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) {}; image = it.toString() } }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "إضافة صيانة" else "تعديل الصيانة") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(type, { type = it }, label = { Text("نوع الصيانة") }); OutlinedTextField(date, { date = it }, label = { Text("التاريخ YYYY-MM-DD") }); OutlinedTextField(due, { due = it }, label = { Text("الاستحقاق القادم (اختياري)") }); OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }); OutlinedButton({ picker.launch(arrayOf("image/*")) }) { Icon(Icons.Default.AddPhotoAlternate, "صورة السجل"); Spacer(Modifier.width(6.dp)); Text(if (image == null) "إضافة صورة للسجل" else "تغيير صورة السجل") }; if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error) } }, confirmButton = { Button({ try { LocalDate.parse(date); if (due.isNotBlank()) LocalDate.parse(due); if (type.isBlank()) { error = "اكتب نوع الصيانة"; return@Button }; onSave(ServiceRecord(existing?.id ?: System.currentTimeMillis(), type.trim(), date, due.ifBlank { null }, notes.trim(), image)) } catch (_: Exception) { error = "صيغة التاريخ لازم تكون YYYY-MM-DD" } }) { Text("حفظ") } }, dismissButton = { TextButton(onDismiss) { Text("إلغاء") } })
}

@Composable fun FuelEditor(existing: FuelRecord?, onDismiss: () -> Unit, onSave: (FuelRecord) -> Unit) {
    val context = LocalContext.current
    var date by remember { mutableStateOf(existing?.date ?: LocalDate.now().toString()) }; var amount by remember { mutableStateOf(existing?.amount ?: "") }; var notes by remember { mutableStateOf(existing?.notes ?: "") }; var image by remember { mutableStateOf(existing?.imageUri) }; var error by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) {}; image = it.toString() } }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "إضافة تعبئة بنزين" else "تعديل التعبئة") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(date, { date = it }, label = { Text("التاريخ YYYY-MM-DD") }); OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ أو الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)); OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }); OutlinedButton({ picker.launch(arrayOf("image/*")) }) { Icon(Icons.Default.AddPhotoAlternate, "صورة التعبئة"); Spacer(Modifier.width(6.dp)); Text(if (image == null) "إضافة صورة للتعبئة" else "تغيير صورة التعبئة") }; if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error) } }, confirmButton = { Button({ try { LocalDate.parse(date); if (amount.isBlank()) { error = "أدخل المبلغ أو الكمية"; return@Button }; onSave(FuelRecord(existing?.id ?: System.currentTimeMillis(), date, amount.trim(), notes.trim(), image)) } catch (_: Exception) { error = "صيغة التاريخ لازم تكون YYYY-MM-DD" } }) { Text("حفظ") } }, dismissButton = { TextButton(onDismiss) { Text("إلغاء") } })
}